package mypackage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.common.collect.Lists;

public class SeleniumTests {

	public Map<String, Double> orderMap = new HashMap<>();
	@Test
	public void test1()
	{
	
	System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	WebDriver dr=new ChromeDriver();
	dr.manage().window().maximize();
	//1. enter to ebay
	dr.get("https://www.ebay.com/");
	dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	// 2.  search shoes
	dr.findElement(By.id("gh-ac")).sendKeys("shoes");
	dr.findElement(By.id("gh-btn")).click();
	// 3. select brand PUME
	dr.findElement(By.cssSelector("input[type='text'][placeholder='Search in all available brands'][class='search']")).sendKeys("PUMA");
	dr.findElement(By.cssSelector("input[aria-label='PUMA'][type='checkbox'][name='Brand']")).click();
	// 4. select size 10
	dr.findElement(By.cssSelector("input[aria-label='10'][type='checkbox'][name *='Size']")).click();
	// 5. print number of result
	WebElement numOfResult = dr.findElement(By.className("rcnt"));
	System.out.println("Number of result is = "+numOfResult.getText()+"\n ===================");
	// 6. order by price ascending
	WebElement bestMatchFilter= dr.findElement(By.cssSelector("a[role='button'][aria-controls='SortMenu'][class *='dropdown-toggle']"));
	Actions builder = new Actions(dr);
	builder.moveToElement(bestMatchFilter).click().build().perform();
	
	List <WebElement> alloption= dr.findElements(By.cssSelector("#SortMenu li"));
	//6. filter order by price ascending
	for(WebElement temp:alloption)
	{
		if(temp.getText().contains("Price + Shipping: lowest first"))
		{
			temp.click();
			break;
		}
	}
	List<Double> productAmountList = new ArrayList<Double>() ;
	
	int count=1;
	List<WebElement> productList = dr.findElements(By.cssSelector("#ResultSetItems #GalleryViewInner li"));
	for(WebElement temp:productList)
	{
		double totalAmount=0.0;
		double amount= Double.parseDouble(temp.findElements(By.className("amt")).get(0).getText().substring(1));
		String description = temp.findElement(By.className("gvtitle")).getText();
		String shippingCharge= temp.findElements(By.className("amt")).get(1).getText();
		shippingCharge = shippingCharge.substring(2, shippingCharge.indexOf("shipping")-1);
		double shipCharge=Double.parseDouble(shippingCharge);
		
		totalAmount = amount+shipCharge;
		//System.out.println(totalAmount);
		productAmountList.add(totalAmount);
		orderMap.put(description, totalAmount);
		count++;
		if(count==6)
		{
			break;
		}
	}
	
	//7. assert the prder taking first five result
	for(int i=0;i<4;i++)
	{
		Assert.assertTrue(productAmountList.get(i)<productAmountList.get(i+1));
	}
	 // This map stores unsorted values
   //8. print the first five in consol
  printFirstFiveOrder();
    // 9. order and print the products by name ascending
	sortbykey();
	//10 product by price in descending order
	sortbyValue();
	}
	 public void printFirstFiveOrder() {
		// Print the content of the hashMap
		 System.out.println("First five producty and price ");
	        Set<Entry<String,Double>> hashSet=orderMap.entrySet();
	        for(Entry entry:hashSet ) {

	            System.out.println("Key="+entry.getKey()+", Value="+entry.getValue());
	        }
	        System.out.println("\n ==============================");
	}
	public  void sortbykey()
	    {
	        // TreeMap to store values of HashMap
	        TreeMap<String, Double> sorted = new TreeMap<>(orderMap);
	 System.out.println("order and print the products by name ascending");
	        // Display the TreeMap which is naturally sorted
	        for (Map.Entry<String, Double> entry : sorted.entrySet()) 
	            System.out.println("Key = " + entry.getKey() + 
	                         ", Value = " + entry.getValue()); 
	        
	        System.out.println("\n ==============================");
	    }
	 
	 public void sortbyValue()
	 {
		 
		 System.out.println("product by price in descending order");
		 
		 Object[] a = orderMap.entrySet().toArray();
		 Arrays.sort(a, new Comparator() {
		     public int compare(Object o1, Object o2) {
		         return ((Map.Entry<String, Double>) o2).getValue()
		                    .compareTo(((Map.Entry<String, Double>) o1).getValue());
		     }
		 });
		 for (Object e : a) {
		     System.out.println(((Map.Entry<String, Double>) e).getKey() + " : "
		             + ((Map.Entry<String, Double>) e).getValue());
		 }	 
		 System.out.println("\n ==============================");	 
	 }
}
